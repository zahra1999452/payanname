# H2: historical source and evidence scope

See the root README and hypothesis_tests/README.md. These scripts were preserved
from the local thesis project; compile checks do not validate training/inference.
For the final H2 inference use the root h2_wilcoxon_holm_verified_v2.py only.
H3 is controlled synthetic. H4 is descriptive/unverified; its legacy inference
entry point is disabled. Do not treat historical script titles as verified claims.
