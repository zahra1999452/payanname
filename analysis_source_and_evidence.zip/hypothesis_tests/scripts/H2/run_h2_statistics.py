"""Compatibility CLI: delegate to the sole verified H2 implementation at repo root."""
from pathlib import Path
import runpy

if __name__ == "__main__":
    runpy.run_path(str(Path(__file__).resolve().parents[3] / "h2_wilcoxon_holm_verified_v2.py"), run_name="__main__")
