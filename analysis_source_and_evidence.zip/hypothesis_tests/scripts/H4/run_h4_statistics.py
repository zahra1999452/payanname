"""Historical H4 inferential entry point disabled in the reviewed evidence release.

Paired raw H4 observations/evaluation configuration have not been recovered.
This revision cannot establish target-domain improvement or reproduce prior p/CI.
"""
def main():
    raise NotImplementedError(
        "H4 is descriptive/unverified. Recover paired raw data and define a "
        "reviewed target-domain protocol before introducing inferential results."
    )

if __name__ == "__main__":
    main()
